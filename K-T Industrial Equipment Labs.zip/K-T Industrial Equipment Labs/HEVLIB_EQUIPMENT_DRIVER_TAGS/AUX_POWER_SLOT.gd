extends Node

const small = {
	"slots":["aux.power"],
	"type":"MPDG",
	"system":"SYSTEM_AUX_K-T_IND_MPD",
	"price":150000,
	"repair_time":1,
	"fix_price":6000,
	"fix_time":2,
	"command":"",
	"power_draw":30000,
	"thermal":2000000,
	"power_supply":250000,
	"windup_time":10,
	"mass":2000
}
const micro = {
	"slots":["aux.power"],
	"type":"MPDG",
	"system":"SYSTEM_AUX_K-T_IND_MB_MPD",
	"price":35000,
	"repair_time":1,
	"fix_price":2500,
	"fix_time":2,
	"command":"",
	"power_draw":20000,
	"thermal":250000,
	"power_supply":150000,
	"windup_time":3,
	"mass":1000
}
const big = {
	"slots":["aux.power"],
	"type":"MPDG",
	"system":"SYSTEM_AUX_K-T_IND_MB_MPD",
	"price":1500000,
	"repair_time":1,
	"fix_price":12000,
	"fix_time":2,
	"command":"",
	"power_draw":100000,
	"thermal":3000000,
	"power_supply":5000000,
	"windup_time":15,
	"mass":8000
}

const SYSTEM_THRUSTER_KTI_MTR_Thruster = {
	"slots":["propulsion.rcs"],
	"type":"RCS",
	"system":"SYSTEM_THRUSTER_KTI",
	"path":"res://K-T Industrial Equipment Labs/sfx/KTI-MTR_Thruster.tscn",
}
const SYSTEM_THRUSTER_KTI_MPR_EIT = {
	"slots":["propulsion.rcs"],
	"type":"RCS",
	"system":"SYSTEM_THRUSTER_KTI-MPR_EIT",
	"path":"res://K-T Industrial Equipment Labs/sfx/KTI-MTR_Thruster.tscn",
}
const SYSTEM_MAIN_ENGINE_KTI_MPR_EIZAP = {
	"slots":["propulsion.main"],
	"type":"TORCH",
	"system":"SYSTEM_MAIN_ENGINE_KTI",
	"path":"res://K-T Industrial Equipment Labs/sfx/SYSTEM_MAIN_ENGINE_KTI-MPR_EIZAP.tscn",
}
