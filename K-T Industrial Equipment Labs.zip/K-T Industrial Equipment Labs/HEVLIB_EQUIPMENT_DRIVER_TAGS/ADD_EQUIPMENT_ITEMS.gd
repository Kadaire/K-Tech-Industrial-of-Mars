extends Node

const MPR_RCS = {
	"system":"SYSTEM_THRUSTER_KTI-MPR_EIT",
	"manual":"SYSTEM_THRUSTER_MANUAL",
	"price":35000,
	"test_protocol":"autopilot",
	"slot_type":"STANDARD_REACTION_CONTROL_THRUSTERS",
	"equipment_type":"THRUSTER_STANDARD_REACTION_CONTROL_THRUSTERS",
	"config":{
		"id":"K-TechIndustrialEquipmentLabs",
		"section":"KTIE_THRUSTERS",
		"entry":"mpr_rcs"
	},
}
const MPR_TORCH = {
	"system":"SYSTEM_MAIN_ENGINE_KTI",
	"manual":"SYSTEM_MAIN_ENGINE_MANUAL",
	"price":1250000,
	"test_protocol":"autopilot",
	"slot_type":"STANDARD_MAIN_ENGINE",
	"equipment_type":"THRUSTER_STANDARD_MAIN_ENGINE",
	"config":{
		"id":"K-TechIndustrialEquipmentLabs",
		"section":"KTIE_THRUSTERS",
		"entry":"mpr_torch"
	},
}
const MTR_RCS = {
	"system":"SYSTEM_THRUSTER_KTI",
	"manual":"SYSTEM_THRUSTER_MANUAL",
	"price":6000,
	"test_protocol":"autopilot",
	"slot_type":"STANDARD_REACTION_CONTROL_THRUSTERS",
	"equipment_type":"THRUSTER_STANDARD_REACTION_CONTROL_THRUSTERS",
	"config":{
		"id":"K-TechIndustrialEquipmentLabs",
		"section":"KTIE_THRUSTERS",
		"entry":"mtr_rcs"
	},
}
const SMALL_BLOCK = {
	"system":"SYSTEM_AUX_K-T_IND_MPD",
	"manual":"SYSTEM_AUX_MPD_MANUAL",
	"price":150000,
	"test_protocol":"bootup",
	"slot_type":"AUX_POWER_SLOT",
	"equipment_type":"POWER_AUX_POWER_SLOT",
	"config":{
		"id":"K-TechIndustrialEquipmentLabs",
		"section":"KTIE_AUXUNITS",
		"entry":"small_block"
	},
}
const MICRO_BLOCK = {
	"system":"SYSTEM_AUX_K-T_IND_MB_MPD",
	"manual":"SYSTEM_AUX_MPD_MANUAL",
	"price":35000,
	"test_protocol":"bootup",
	"slot_type":"AUX_POWER_SLOT",
	"equipment_type":"POWER_AUX_POWER_SLOT",
	"config":{
		"id":"K-TechIndustrialEquipmentLabs",
		"section":"KTIE_AUXUNITS",
		"entry":"micro_block"
	},
}
const BIG_BLOCK = {
	"system":"SYSTEM_AUX_KTI_BB_MPD",
	"manual":"SYSTEM_AUX_MPD_MANUAL",
	"price":1500000,
	"test_protocol":"bootup",
	"slot_type":"AUX_POWER_SLOT",
	"equipment_type":"POWER_AUX_POWER_SLOT",
	"config":{
		"id":"K-TechIndustrialEquipmentLabs",
		"section":"KTIE_AUXUNITS",
		"entry":"big_block"
	},
}
