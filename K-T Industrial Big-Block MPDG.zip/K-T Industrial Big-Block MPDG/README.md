# K-Tech Industrial presents the: 

## Block series MPDGs: 

A series of new MPDG's for the hard working industrial miner, The Big-Block series is designed to be the answer to all your power generation needs. 


Mod notes: 

This mod simply aims to add new MPDG systems to the game. 
An optional download for the end game "Big-Block" model MPDG which installs as a separate mod due to being considerably stronger than any vanilla MPDG.
This does NOT require you to use the main "K-Tech Industrial Block series" MPDG mod, it works as a standalone or can be loaded with the other mod.


## Information:
- Adds a new MPDG: `K-T Industrial Big-Block RTG`
- Cost: `1,500,000 E$`
- Electrical Draw: `100MW`
- Thermal Draw: `3GW`
- Power Output: `5000MW`
- Requires: `nothing, this is a standalone MPDG competitor to the weaker vanilla "MPI Town-Class" series MPDG,.`


# Important Compatiblity Note:
**`K-Tech Industrial` Branded Mods DO NOT currently work with the Industries of Enceladus mod. There is no current workaround for this. Will update this section if that changes.**

# Important Compatiblity Note:
**`K-Tech Industrial` Branded Mods DO NOT currently work with the Industries of Enceladus mod. There is no current workaround for this. Will update this section if that changes.**
