# K-Tech Industrial presents the: 

## Block series MPDGs: 

A series of new MPDG's for the hard working industrial miner, the Micro-Block series RTG allows new miners to add a small bit of extra power for that extra kick a new tool might need. The Small-Block series is another entry level competitor to the MPDG market costing slightly more but producing almost 2x the power of the RTG.   The Big-Block series is designed to be the answer to all your power generation needs. 


Mod notes: 

This mod simply aims to add new MPDG systems to the game. 
The entry level option, "Small-Block" series MPDG. 
And an optional download for the end game "Big-Block" model which installs as a separate mod due to being considerably stronger than any vanilla MPDG.


## Information:
- Adds a new MPDG: `K-T Industrial Small-Block RTG`
- Cost: `150,000 E$`
- Electrical Draw: `40MW`
- Thermal Draw: `2GW`
- Power Output: `350MW`
- Requires: `nothing, this is a standalone MPDG, a cheaper alternative to the MPD5035 series MPDG, producing slightly less power at half the cost.`


# Important Compatiblity Note:
**`K-Tech Industrial` Branded Mods DO NOT currently work with the Industries of Enceladus mod. There is no current workaround for this. Will update this section if that changes.**
