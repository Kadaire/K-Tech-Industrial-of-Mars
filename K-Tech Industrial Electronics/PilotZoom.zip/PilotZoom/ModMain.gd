extends Node

const MOD_PRIORITY = 0
const MOD_NAME = "PilotZoom"
const MOD_VERSION = "1.0.1"
var modPath:String = get_script().resource_path.get_base_dir() + "/"
var modLoader = false
var _savedObjects := []

func _init(__):
	l("Initializing")
	replaceScene("hud/OMS.tscn")
	l("Initialized")

func _ready():
	l("Ready")

# Func to print messages to the logs
func l(msg:String, title:String = MOD_NAME):
	Debug.l("[%s]: %s" % [title, msg])


# Helper function to replace scenes
# Can either be passed a single path, or two paths
# With a single path, it will replace the vanilla scene in the same relative position
func replaceScene(newPath:String, oldPath:String = ""):
	l("Updating scene: %s" % newPath)

	if oldPath.empty():
		oldPath = str("res://" + newPath)

	newPath = str(modPath + newPath)

	var scene := load(newPath)
	scene.take_over_path(oldPath)
	_savedObjects.append(scene)
	l("Finished updating: %s" % oldPath)

