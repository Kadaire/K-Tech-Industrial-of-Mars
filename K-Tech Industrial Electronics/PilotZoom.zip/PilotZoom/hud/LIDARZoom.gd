extends Node

export (NodePath) var target

func _ready():
	target = get_node(target)

func _on_HSlider_value_changed(value):
	target.distance = value
