# K-Tech Industrial presents the: 

## Block series MPDGs: 

A series of new MPDG's for the hard working industrial miner. 
The Micro-Block series RTG allows new miners to add a small bit of extra power for that extra kick a new tool might need. 
The Small-Block series is another entry level competitor to the MPDG market costing slightly more but producing almost 2x the power of the RTG.   
The Big-Block series is designed to be the answer to all your power generation needs. 


Mod notes: 

This mod simply aims to add a new MPDG system to the game.
The entry level option, "Micro-Block" series RTG.


## Information:
- Adds a new MPDG: `K-T Industrial Micro-Block RTG`
- Cost: `30,000 E$`
- Electrical Draw: `20MW`
- Thermal Draw: `0.25GW`
- Power Output: `150MW`
- Requires: `nothing, this is a standalone MPDG, An entry level power generator for newly established ring miners.`


# Important Compatiblity Note:
**`K-Tech Industrial` Branded Mods DO NOT currently work with the Industries of Enceladus mod. There is no current workaround for this. Will update this section if that changes.**
